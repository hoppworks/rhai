//! Bounded capture of exact process handles from one owned Windows job.
//!
//! A snapshot alone cannot establish that every process ever assigned was captured.
//! The caller must separately prove capture completeness before accepting job closure.

use super::job::ManagedJob;
use std::collections::BTreeMap;
use std::io;
use std::os::windows::io::{AsRawHandle, FromRawHandle, OwnedHandle, RawHandle};
use std::ptr;
use windows_sys::Win32::Foundation::{HANDLE, WAIT_FAILED, WAIT_OBJECT_0, WAIT_TIMEOUT};
use windows_sys::Win32::System::JobObjects::{
    IsProcessInJob, JobObjectBasicProcessIdList, QueryInformationJobObject,
};
use windows_sys::Win32::System::Threading::{
    OpenProcess, WaitForSingleObject, PROCESS_QUERY_LIMITED_INFORMATION, PROCESS_SYNCHRONIZE,
};

const MAX_CAPTURED_MEMBERS: usize = 256;

#[repr(C)]
struct ProcessList {
    assigned: u32,
    listed: u32,
    ids: [usize; MAX_CAPTURED_MEMBERS],
}

/// Handles are never replaced based on a fresh PID lookup; holding each handle
/// prevents identity reuse while this capture remains live.
#[derive(Default)]
pub(super) struct CapturedMembers {
    handles: BTreeMap<u32, OwnedHandle>,
}

impl CapturedMembers {
    /// Resolve a bounded membership snapshot to handles that are still in this job.
    /// An identity can change between the snapshot and `OpenProcess`; a successful
    /// call does not bind a handle retroactively to that earlier PID observation.
    /// Already captured handles remain owned by `self` on an error.
    pub(super) fn capture(&mut self, job: &ManagedJob) -> io::Result<()> {
        let mut list = ProcessList {
            assigned: 0,
            listed: 0,
            ids: [0; MAX_CAPTURED_MEMBERS],
        };
        // SAFETY: job is owned; list has correct C layout, alignment and writable size.
        if unsafe {
            QueryInformationJobObject(
                job.handle(),
                JobObjectBasicProcessIdList,
                &mut list as *mut _ as *mut _,
                std::mem::size_of_val(&list) as u32,
                ptr::null_mut(),
            )
        } == 0
        {
            return Err(io::Error::last_os_error());
        }
        if list.assigned != list.listed || list.listed as usize > MAX_CAPTURED_MEMBERS {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "incomplete managed job membership list",
            ));
        }
        for raw_pid in list.ids[..list.listed as usize].iter().copied() {
            let pid = u32::try_from(raw_pid).map_err(|_| {
                io::Error::new(io::ErrorKind::InvalidData, "invalid managed process id")
            })?;
            if pid == 0 {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "zero managed process id",
                ));
            }
            if self.handles.contains_key(&pid) {
                continue;
            }
            if self.handles.len() >= MAX_CAPTURED_MEMBERS {
                return Err(io::Error::new(
                    io::ErrorKind::Other,
                    "managed process handle capacity reached",
                ));
            }
            // SAFETY: the PID came from this owned job's bounded snapshot; no process is signaled.
            let raw = unsafe {
                OpenProcess(
                    PROCESS_SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION,
                    0,
                    pid,
                )
            };
            if raw.is_null() {
                return Err(io::Error::last_os_error());
            }
            // SAFETY: OpenProcess returned a fresh owned process handle.
            let handle = unsafe { OwnedHandle::from_raw_handle(raw as RawHandle) };
            let mut member = 0;
            // SAFETY: handle and job are live and member points to writable storage.
            if unsafe {
                IsProcessInJob(handle.as_raw_handle() as HANDLE, job.handle(), &mut member)
            } == 0
            {
                return Err(io::Error::last_os_error());
            }
            if member == 0 {
                return Err(io::Error::new(
                    io::ErrorKind::Other,
                    "captured process is no longer a member of its job",
                ));
            }
            self.handles.insert(pid, handle);
        }
        Ok(())
    }

    pub(super) fn len(&self) -> usize {
        self.handles.len()
    }

    /// A false result means at least one exact captured handle has not signaled.
    /// True for an empty or incomplete capture does not establish job closure.
    pub(super) fn all_signaled(&self) -> io::Result<bool> {
        let mut all = true;
        for handle in self.handles.values() {
            // SAFETY: each process handle remains owned for the nonblocking observation.
            match unsafe { WaitForSingleObject(handle.as_raw_handle() as HANDLE, 0) } {
                WAIT_OBJECT_0 => {}
                WAIT_TIMEOUT => all = false,
                WAIT_FAILED => return Err(io::Error::last_os_error()),
                other => {
                    return Err(io::Error::new(
                        io::ErrorKind::Other,
                        format!("unexpected process wait result {other:#x}"),
                    ))
                }
            }
        }
        Ok(all)
    }

    /// Candidate closure check for a private job after new assignments are barred.
    /// An unobserved association fails closed, including short-lived processes.
    /// Native race/fault proof is required before this can establish acceptance.
    pub(super) fn candidate_closed(&self, job: &ManagedJob) -> io::Result<bool> {
        let (active, total) = job.process_counts()?;
        if total as usize != self.handles.len() {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "managed job lifetime membership was not completely captured",
            ));
        }
        if active != 0 || !self.all_signaled()? {
            return Ok(false);
        }
        let (active_after, total_after) = job.process_counts()?;
        if total_after != total {
            return Err(io::Error::new(
                io::ErrorKind::Other,
                "managed job membership changed during closure observation",
            ));
        }
        Ok(active_after == 0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use std::process::{Child, Command, Stdio};
    use std::thread;
    use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
    use windows_sys::Win32::System::JobObjects::AssignProcessToJobObject;

    const RECORD_ENV: &str = "RHAI_WINDOWS_MEMBER_CAPTURE_RECORD";

    /// This owned fixture performs no descendant work before the parent assigns its job.
    #[test]
    fn capture_fixture() {
        let Ok(record) = std::env::var(RECORD_ENV) else {
            return;
        };
        let record = std::path::Path::new(&record);
        std::fs::write(record, format!("{}\n", std::process::id())).unwrap();
        let deadline = Instant::now() + Duration::from_secs(20);
        while Instant::now() < deadline {
            if record.with_extension("release").exists() {
                std::process::exit(0);
            }
            thread::sleep(Duration::from_millis(10));
        }
        panic!("member capture fixture timed out");
    }

    struct Fixture {
        child: Option<Child>,
        job: Option<ManagedJob>,
        root: PathBuf,
        record: PathBuf,
    }
    impl Fixture {
        fn new() -> Self {
            let nonce = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos();
            let root = std::env::temp_dir()
                .join(format!("rhai-job-capture-{}-{nonce}", std::process::id()));
            std::fs::create_dir(&root).unwrap();
            let record = root.join("child.pid");
            let job = ManagedJob::new().expect("create private job");
            let child = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "packages::sys::process::windows::members::tests::capture_fixture",
                    "--nocapture",
                    "--quiet",
                ])
                .env_clear()
                .env(RECORD_ENV, &record)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .spawn()
                .expect("start gated capture fixture");
            let fixture = Self {
                child: Some(child),
                job: Some(job),
                root,
                record,
            };
            // SAFETY: both exact handles are owned by fixture throughout the assignment.
            assert_ne!(
                unsafe {
                    AssignProcessToJobObject(
                        fixture.job().handle(),
                        fixture.child().as_raw_handle() as HANDLE,
                    )
                },
                0,
                "assign gated fixture to private job: {}",
                io::Error::last_os_error()
            );
            let deadline = Instant::now() + Duration::from_secs(5);
            loop {
                match std::fs::read_to_string(&fixture.record) {
                    Ok(value) => {
                        assert_eq!(value.trim().parse::<u32>().unwrap(), fixture.child().id());
                        break;
                    }
                    Err(error)
                        if error.kind() == io::ErrorKind::NotFound && Instant::now() < deadline =>
                    {
                        thread::sleep(Duration::from_millis(10))
                    }
                    Err(error) => panic!("capture fixture readiness: {error}"),
                }
            }
            fixture
        }
        fn child(&self) -> &Child {
            self.child.as_ref().unwrap()
        }
        fn job(&self) -> &ManagedJob {
            self.job.as_ref().unwrap()
        }
        fn wait(&mut self) {
            // SAFETY: fixture holds the exact child handle during this bounded wait.
            assert_eq!(
                unsafe { WaitForSingleObject(self.child().as_raw_handle() as HANDLE, 10_000) },
                WAIT_OBJECT_0
            );
            self.child
                .as_mut()
                .unwrap()
                .wait()
                .expect("observe direct child exit");
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            let Some(mut child) = self.child.take() else {
                return;
            };
            // SAFETY: child remains owned during both exact-handle observations.
            if unsafe { WaitForSingleObject(child.as_raw_handle() as HANDLE, 0) } != WAIT_OBJECT_0 {
                if let Some(job) = self.job.as_ref() {
                    let _ = job.terminate();
                }
                let _ = child.kill();
            }
            if unsafe { WaitForSingleObject(child.as_raw_handle() as HANDLE, 10_000) }
                != WAIT_OBJECT_0
            {
                eprintln!(
                    "capture fixture exit unconfirmed; retain handles and files for outer job"
                );
                std::mem::forget(child);
                if let Some(job) = self.job.take() {
                    std::mem::forget(job);
                }
                return;
            }
            let _ = child.wait();
            let _ = std::fs::remove_dir_all(&self.root);
        }
    }

    #[test]
    fn captured_process_handle_requires_real_exit_before_candidate_closure() {
        let mut fixture = Fixture::new();
        let mut members = CapturedMembers::default();
        members
            .capture(fixture.job())
            .expect("capture owned fixture");
        assert_eq!(members.len(), 1);
        assert!(!members.all_signaled().unwrap());
        assert!(!members.candidate_closed(fixture.job()).unwrap());
        fixture
            .job()
            .terminate()
            .expect("terminate exact fixture job");
        fixture.wait();
        let deadline = Instant::now() + Duration::from_secs(5);
        let closed = loop {
            match members.candidate_closed(fixture.job()) {
                Ok(true) => break true,
                Ok(false) if Instant::now() < deadline => thread::sleep(Duration::from_millis(10)),
                other => panic!("captured fixture closure: {other:?}"),
            }
        };
        assert!(members.all_signaled().unwrap());
        eprintln!("windows_member_capture_readback captured=1 exact_handle_signaled=true");
        drop(members);
        drop(fixture);
        if std::env::var_os("RHAI_WINDOWS_MEMBER_CAPTURE_WRONG_EXPECTATION").is_some() {
            assert!(
                !closed,
                "deliberately wrong captured member closure expectation"
            );
        }
    }

    #[test]
    fn unobserved_lifetime_member_cannot_certify_candidate_closure() {
        let mut fixture = Fixture::new();
        std::fs::write(fixture.record.with_extension("release"), b"release\n").unwrap();
        fixture.wait();
        let members = CapturedMembers::default();
        let result = members.candidate_closed(fixture.job());
        assert!(
            result.is_err(),
            "an uncaptured association must remain unverified"
        );
        eprintln!("windows_member_capture_missing_readback unverified=true");
        drop(members);
        drop(fixture);
        if std::env::var_os("RHAI_WINDOWS_MEMBER_MISSING_WRONG_EXPECTATION").is_some() {
            assert!(
                result.is_ok(),
                "deliberately wrong uncaptured member expectation"
            );
        }
    }
}
