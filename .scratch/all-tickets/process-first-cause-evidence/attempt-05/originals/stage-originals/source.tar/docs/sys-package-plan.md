# Rhai `sys` package: contract, requirements matrix, and plan

Current status (2026-10-07): implementation resumed by the owner's explicit
instruction. Package A, committed Child cause, is complete at its bounded Linux /
Rust 1.77.2 acceptance scope after four native allocations. Attempt 4 passed four
intended baseline/mutant RED controls and both restored GREEN controls in one
archive. The production fix is present in the writer worktree at the exact tested
source hash `fced800d5b05a1582a4d1c27cadabda32dc1517522e5ed733865d7faab48e5d4`;
the combined independent review returned READY with no material code findings.
Independent readback and closure verified the preserved originals, process
identities, groups and paths before the exact Workhorse stage and private runtime
were retired. No compiled build is reusable. The package evidence is under
`../.scratch/all-tickets/process-first-cause-evidence/originals/`. Packages B–F,
the remaining ticket criteria, integrated platform acceptance and release closure
remain open; no full ticket or release completion is claimed.

Historical status: decisions D1 to D12 accepted on 2026-09-29; phase 1 implemented on branch
`claude/vibrant-sagan-3g1pxn` (this fork only, no upstream submission yet). Supersedes the
2026-09-29 precedents survey; that survey is condensed into Appendix A.

Review update (2026-09-30): phase 1 is implemented but not accepted under the new
strict verification contract. Four filesystem/fixture findings remain open. The
owner-approved [path contract](../.scratch/stdlib-wayfinder/issues/02-filesystem-contract.md#answer)
clarifies required behavior; historical implementation notes below are not proof
that those requirements pass.

The package gives Rhai scripts access to the host filesystem, environment, and child
processes. The host decides how much authority a script gets. Nothing in this package is
enabled by default.

## 1. Goal and non-goals

Goal for the first release (v0.1 of the package, gated behind the `sys` cargo feature):

- Environment: read variables and the working directory.
- Filesystem: whole-file read and write, directory listing and mutation, metadata.
- Processes: run a program to completion with captured output, or spawn it and wait, with
  timeout, output cap, stdin data, and kill.
- Authority: every capability above is granted by a host-built `SysConfig`; the default
  config denies everything.

Non-goals for v0.1, deferred to later phases or separate packages:

- Networking (TCP, UDP, HTTP). Separate package, separate feature, separate plan.
- Async or event-loop integration. All calls block the calling thread.
- Shell execution. No `sh -c`, no `cmd /C`, no string command lines.
- Streaming file handles. rhai-fs already provides these; v0.2 adds a compatible subset.
- Mutating the process environment (`set_var`). Process-global, unsound with threads.

## 2. Decisions

Each decision names a recommendation. Items marked "needs owner sign-off" block the next phase.

| ID | Topic | Recommendation | Rationale | Status |
|---|---|---|---|---|
| D1 | Where the code lives | In-tree at `src/packages/sys/`, behind cargo feature `sys`, not part of `StandardPackage` or the `default` feature set. | Fastest path on this fork. Extracting to a `rhai-sys` crate later is mechanical, because the package only uses the public plugin API. | accepted |
| D2 | Authority model | Host constructs `SysConfig` (fs roots, program allow-list, env policy, limits) and builds `SysPackage::new(config)`. `SysConfig::default()` denies everything; `SysConfig::permissive()` allows everything for trusted scripts. | Matches Deno's permission model and the "explicit authority" conclusion of the survey. Deny-by-default means forgetting to configure is safe. | accepted |
| D3 | Filesystem confinement | Use the `cap-std` crate. Each configured root becomes a `cap_std::fs::Dir`; script paths resolve relative to a root and cannot escape it, including via symlinks. | Hand-rolled `canonicalize` + `starts_with` checks are racy against symlink changes. `cap-std` is maintained by the Bytecode Alliance and is the reference implementation of this idea. Optional dependency, pulled only by `sys`. | accepted |
| D4 | Process API shape | Options-map style, not a builder: `run(program, args)` and `run(program, args, options)` return a result map; `spawn(program, args, options)` returns a `Child` handle. | Rhai plugin methods on `&mut T` return unit, so builder chaining does not work without cloning. An options map is idiomatic Rhai, trivially serializable, and easy to test. Rune's process module shows the builder style and its awkwardness. | accepted |
| D5 | Error model | OS and policy failures raise `EvalAltResult::ErrorRuntime` whose payload is a `SysError` value (enum: `Denied`, `Io`, `Timeout`, `OutputLimit`, `NotUtf8`) registered as a script type with getters `kind`, `message`, `io_kind`, `op`, `target`. Scripts catch it with `try`/`catch`. A non-zero exit code is data in the result map, never an error. | Mirrors Rust: `Command::output()` succeeds on non-zero exit. Hosts get the value back with `Dynamic::try_cast::<SysError>()`. Rhai's `ErrorSystem` was the first choice but the interpreter marks it uncatchable (`EvalAltResult::is_catchable`), which would defeat script-side handling; `SysError::Io` therefore stores `io::ErrorKind` plus message instead of the non-`Clone` `io::Error`. | accepted, revised during phase 1 |
| D6 | Paths | Strings in, strings out. Non-UTF-8 names raise `SysError::NotUtf8`. No opaque path type in v0.1. | Rhai strings are UTF-8, `OsString` is not. Keep the surface small; a `Path` type can come with rhai-fs compatibility in v0.2. | accepted |
| D7 | Timeout | Poll `Child::try_wait()` at a coarse interval (10 ms) until the deadline, then kill and mark `timed_out: true`. No extra thread, no extra dependency. | `std` has no `wait` with timeout. Polling is portable and adequate for script use. | accepted |
| D8 | Windows batch files | Refuse programs ending in `.bat` or `.cmd` unless the config sets `allow_batch_files`. Document MSRV 1.77.2 for the `sys` feature. | CVE-2024-24576: Windows batch arguments pass through `cmd.exe` and were injectable. `std` fixed quoting in 1.77.2; refusing by default removes the whole class. | accepted |
| D9 | Child drop semantics | `kill_on_drop: true` by default; option to disable. `Child` is `Shared<Locked<...>>` so it works under `sync`. | Scripts are short-lived and error-prone; an orphaned child outliving the script is the surprising outcome. Rust's `Child` neither kills nor reaps on drop, so the package must. | accepted |
| D10 | Feature gating | `sys` implies `std`. Combining `sys` with `no_std` or a wasm32 target is a `compile_error!`. | Nothing here can work without an OS. Failing loudly beats an empty package. | accepted |
| D11 | Output encoding | `run` returns `stdout` and `stderr` as strings, lossily converted. `run_raw` returns blobs. | Most scripts want text. Lossy conversion never fails; scripts needing bytes opt in. | accepted |
| D12 | rhai-fs compatibility | Where a v0.1 function overlaps rhai-fs (`cwd`, `exists`, `create_dir`, `remove_dir`, `remove_file`), keep the same name and argument order. Divergences are listed in the docs. | Two incompatible fs APIs in one ecosystem help nobody. | accepted |

## 3. Script-facing contract (v0.1)

Names are final only after owner review. Everything below is registered by `SysPackage`
as global functions.

### 3.1 Environment

```rhai
env_var("HOME")            // String, or () when unset or not allowed by policy
env_vars()                 // Map of every variable the policy exposes
cwd()                      // String; the process working directory
```

Policy: `EnvPolicy::None` (both functions return empty), `EnvPolicy::AllowList(names)`,
`EnvPolicy::All`.

### 3.2 Filesystem

All paths are resolved against a configured root. An absolute path must lie inside a root;
a relative path is resolved against the first root. `..` and symlinks cannot leave a root
(enforced by `cap-std`, not by string inspection). The host-configured root must
identify the directory selected by OS path resolution, preserving symlink/parent
semantics. Unrestricted mode retains ordinary host filesystem path behavior while
still enforcing the configured access level. Exact alias, traversal, symlink and
multiple-root rules and regression expectations live in the accepted
[path contract](../.scratch/stdlib-wayfinder/issues/02-filesystem-contract.md#accepted-path-contract).

```rhai
read_file(path)                  // String
read_file_blob(path)             // Blob
write_file(path, data)           // data: String or Blob; creates or truncates
append_file(path, data)
exists(path)                     // bool
is_file(path)                    // bool
is_dir(path)                     // bool
metadata(path)                   // #{ size, is_file, is_dir, is_symlink, modified, readonly }
read_dir(path)                   // Array of entry names (not full paths), sorted
create_dir(path)
create_dir_all(path)
remove_file(path)
remove_dir(path)                 // empty directories only
remove_dir_all(path)             // requires FsAccess::ReadWriteDelete
rename(from, to)                 // both inside the same root
copy_file(from, to)
```

Policy: each root carries `FsAccess::Read`, `FsAccess::ReadWrite`, or
`FsAccess::ReadWriteDelete`. A write to a read-only root raises `SysError::Denied`.

### 3.3 Processes

```rhai
let r = run("git", ["status", "--short"]);
let r = run("git", ["status"], #{
    cwd:        "/repo",          // must be inside a configured fs root
    env:        #{ GIT_PAGER: "cat" },
    env_clear:  true,             // start from an empty environment
    env_remove: ["GIT_DIR"],
    stdin:      "input text",     // String or Blob; () closes stdin
    timeout:    5.0,              // seconds; () means none
    max_output: 1_000_000,        // bytes per stream; exceeding it raises SysError::OutputLimit
});
r.success       // bool: code == 0
r.code          // int, or () when killed by a signal (Unix) or timed out
r.signal        // int on Unix when signaled, else ()
r.timed_out     // bool
r.stdout_complete // bool: stdout reached EOF before the run returned
r.stderr_complete // bool: stderr reached EOF before the run returned
r.stdout        // String (lossy UTF-8)
r.stderr        // String
```

`run_raw` takes the same arguments and returns `stdout` and `stderr` as blobs.

```rhai
let c = spawn("long-task", [], #{ stdin: "..." });   // same options minus timeout
c.id            // int
c.try_wait()    // () while running, else the result map above
c.wait()        // blocks; result map
c.wait(10.0)    // blocks up to 10 s; () on timeout
c.kill()        // best effort; idempotent
```

Policy: `ProgramPolicy::None`, `ProgramPolicy::AllowList(names)`, `ProgramPolicy::Any`.
Names in the allow-list are compared against the program string as given; the config may
also pin absolute paths. `cwd` is validated against the fs roots. Arguments are always passed
as a vector, never through a shell.

The initial release also includes host-selected managed process groups/jobs,
alongside direct-child supervision. Managed mode terminates associated workers on
cancellation and closes its task scope at normal completion. Scripts cannot downgrade
host-required supervision; unavailable scope setup fails explicitly. This does not
sandbox file/network access or guarantee termination of escaped descendants.
The precise lifecycle, diagnostics and native acceptance contract is recorded in
[process contract](../.scratch/stdlib-wayfinder/issues/03-process-contract.md#answer).
Configuration spelling and Rust error compatibility remain API-review work.

### 3.4 Host API

```rust
let cfg = SysConfig::default()
    .fs_root("/srv/app/data", FsAccess::ReadWrite)
    .programs(ProgramPolicy::AllowList(vec!["git".into(), "ffmpeg".into()]))
    .env(EnvPolicy::AllowList(vec!["HOME".into(), "PATH".into()]))
    .default_timeout(Some(30.0))
    .max_output(8 * 1024 * 1024)
    .kill_on_drop(true);

let mut engine = Engine::new();
engine.register_global_module(SysPackage::new(cfg).as_shared_module());
```

Errors are values: a caught `SysError` prints as its message, and `type_of(err)` is
`"SysError"`.

```rhai
try {
    read_file("missing.txt");
} catch (err) {
    if err.kind == "Io" && err.io_kind == "NotFound" { /* ... */ }
}
```

## 4. Requirements and test matrix

Every row becomes at least one test. "Source" names the precedent that motivated the case;
tests are written from scratch against this contract. Phase numbers refer to section 6.

### 4.1 Policy (P)

| ID | Case | Expected | Source | Phase |
|---|---|---|---|---|
| P1 | Default config, any fs call | `SysError::Denied` | Deno permissions | 1 |
| P2 | Default config, `run` | `SysError::Denied` | Deno | 2 |
| P3 | Read on read-only root | succeeds | own | 1 |
| P4 | Write on read-only root | `Denied` | own | 1 |
| P5 | `remove_dir_all` on `ReadWrite` root | `Denied`; needs `ReadWriteDelete` | own | 1 |
| P6 | Path with `..` escaping root | `Denied`, and no fs access happened | cap-std, Lua `files.lua` | 1 |
| P7 | Symlink inside root pointing outside | `Denied` | cap-std | 1 |
| P8 | Absolute path inside root | resolves | own | 1 |
| P9 | Absolute path outside any root | `Denied` | own | 1 |
| P10 | Program not in allow-list | `Denied` before spawn | Deno `--allow-run` | 2 |
| P11 | `cwd` option outside fs roots | `Denied` | own | 2 |
| P12 | `env_var` not in allow-list | `()` | own | 1 |
| P13 | `.bat` / `.cmd` program on Windows, default config | `Denied` | CVE-2024-24576 | 3 |
| P14 | Host root contains symlink followed by `..` | OS-selected root only; lexical substitute untouched | review regression | phase 1 repair |

### 4.2 Environment (E)

| ID | Case | Expected | Source | Phase |
|---|---|---|---|---|
| E1 | Variable set in parent | returned | Lua `os.getenv` | 1 |
| E2 | Variable unset | `()` | Lua | 1 |
| E3 | `env_vars()` under `All` | contains a known variable | QuickJS `std.getenviron` | 1 |
| E4 | Non-UTF-8 variable value (Unix only) | `NotUtf8` or skipped in `env_vars`, documented | own | 3 |
| E5 | `cwd()` | equals `std::env::current_dir()` | rhai-fs `cwd` | 1 |

### 4.3 Filesystem (F)

| ID | Case | Expected | Source | Phase |
|---|---|---|---|---|
| F1 | Read existing text file | content | Lua `files.lua` | 1 |
| F2 | Read missing file | `Io` with `NotFound` kind, message includes path | Lua | 1 |
| F3 | Read empty file | `""` | Lua | 1 |
| F4 | Read binary file as string | lossy replacement chars; `read_file_blob` exact | Lua | 1 |
| F5 | Read large file (8 MiB) | exact round trip | own | 1 |
| F6 | Write then read | round trip; write truncates existing content | Lua | 1 |
| F7 | Append twice | concatenated | Lua | 1 |
| F8 | Write blob | bytes exact | rhai-fs `write_to_file` | 1 |
| F9 | Write into missing parent directory | `Io`, no partial file | Lua | 1 |
| F10 | `exists` / `is_file` / `is_dir` | correct on file, dir, missing | rhai-fs getters | 1 |
| F11 | `metadata` on file | size matches, `is_file` true | QuickJS `os.stat` | 1 |
| F12 | `read_dir` | sorted names, no `.`/`..`, no path prefix | mruby-io `Dir` | 1 |
| F13 | `read_dir` on a file | `Io` | Lua | 1 |
| F14 | `create_dir` when parent missing | `Io`; `create_dir_all` succeeds | QuickJS `os.mkdir` | 1 |
| F15 | `remove_dir` on non-empty dir | `Io`; `remove_dir_all` succeeds under `ReadWriteDelete` | Lua `os.remove` | 1 |
| F16 | `rename` across roots | `Denied` | own | 1 |
| F17 | `copy_file` | content equal, source untouched | own | 1 |
| F18 | Unicode filename | round trip | own | 1 |
| F19 | Non-UTF-8 filename in `read_dir` (Unix) | `NotUtf8` | own | 3 |
| F20 | Windows path with forward slashes | works | own | 3 |
| F21 | Windows reserved name (`CON`) | `Io`, does not hang | own | 3 |
| F22 | Unrestricted absolute/sibling-relative symlinks and symlink/parent paths | Corresponding host operation semantics; grants still enforced | review regression | phase 1 repair |
| F23 | Supported configured/canonical/macOS-prefix spellings of a root | Same authority and payload; no permission fallback | review regression | phase 1 repair |

### 4.4 Processes (X)

| ID | Case | Expected | Source | Phase |
|---|---|---|---|---|
| X1 | Program found, exit 0 | `success`, `code == 0` | all | 2 |
| X2 | Program not found | `Io` with `NotFound`, before any child exists | Lua, QuickJS | 2 |
| X3 | Exit code non-zero | `success == false`, `code == N`, no error raised | Rust `Command::output` | 2 |
| X4 | Arguments with spaces and quotes | fixture echoes argv exactly | Deno, Rust std tests | 2 |
| X5 | Argument containing `$HOME`, `|`, `;`, `&&` | passed literally, fixture sees the raw string | Lua `os.execute` (counter-example) | 2 |
| X6 | Empty argument `""` | preserved as an empty argv entry | Rust std tests | 2 |
| X7 | `cwd` option valid | fixture reports that directory | QuickJS `os.exec` | 2 |
| X8 | `cwd` option missing directory | `Io`, no child spawned | QuickJS | 2 |
| X9 | `env` override | fixture sees the value | QuickJS | 2 |
| X10 | `env_clear` | fixture sees only overrides | Rust `env_clear` | 2 |
| X11 | `env_remove` | fixture does not see the variable | Rust `env_remove` | 2 |
| X12 | stdout and stderr separate | each captured on its own | QuickJS | 2 |
| X13 | Both streams write 4 MiB interleaved | no deadlock, both complete | Rust `output()` uses concurrent reads | 2 |
| X14 | Empty output | `""` | Lua | 2 |
| X15 | Binary output | `run_raw` exact bytes; `run` lossy | own | 2 |
| X16 | stdin string | fixture echoes it back | QuickJS pipes | 2 |
| X17 | stdin blob 1 MiB | exact round trip, no deadlock while child also writes | own | 2 |
| X18 | stdin `()` | fixture sees EOF immediately | own | 2 |
| X19 | Timeout expires | `timed_out == true`, termination/reaping observed; watchdog bounds the test; OS latency limitations documented | own | 2 |
| X20 | Timeout not reached | normal result | own | 2 |
| X21 | `max_output` exceeded | `OutputLimit`, child killed | survey "output cap" | 2 |
| X22 | Child killed by signal (Unix) | `code == ()`, `signal == 9` | Rust `ExitStatusExt` | 2 |
| X23 | `spawn` then `wait` | same result map as `run` | Rune process | 2 |
| X24 | `spawn` then `try_wait` while running | `()`; after exit, result | Rune | 2 |
| X25 | `spawn` then `kill` then `wait` | terminated, no hang | Rune | 2 |
| X26 | `kill` twice | second is a no-op, no error | own | 2 |
| X27 | Drop `Child` while running, `kill_on_drop` true | child exits (Linux: verify via `/proc`), no zombie | own | 2 |
| X28 | Drop `Child`, `kill_on_drop` false | child keeps running; retained supervisor eventually reaps it | own | 2 |
| X29 | Script `throw` while child running | child cleaned up via drop | own | 2 |
| X30 | 200 sequential `run` calls | no fd or handle leak (Linux: `/proc/self/fd` count stable) | Lua cleanup tests | 2 |
| X31 | Under `sync` feature, `Child` shared across threads | compiles and works | Rhai `sync` | 2 |
| X32 | Windows: argument with embedded quote | argv reconstructed correctly | Rust std quoting rules | 3 |
| X33 | Windows: `.exe` suffix omitted | resolves via `PATH` | own | 3 |

| X34 | Managed scope cancellation | associated child/grandchild workers stop on timeout, overflow, kill and final drop; independent observations | process contract | 2 |
| X35 | Managed main process exits before workers | owned task scope closes before final result; direct mode remains distinct | process contract | 2 |
| X36 | Managed scope setup fails | no unmanaged work or silent fallback; partial setup cleaned up | process contract | 2 |
| X37 | Host group/job and unrelated sentinel | owned scope cleanup leaves host and sentinel intact | process contract | 2 |
| X38 | Descendant retains pipe or escapes membership | capture cancellation completes; membership limitation explicit; fixture owns escapee cleanup | process contract | 2 |

### 4.5 Engine integration (R)

| ID | Case | Expected | Source | Phase |
|---|---|---|---|---|
| R1 | `sys` off | no symbols exported, no dependency compiled | Rhai feature conventions | 1 |
| R2 | `sys` + `no_std` | `compile_error!` | D10 | 1 |
| R3 | `sys` + `no_index` | `run` without args still works; array-taking overloads absent | Rhai cfg conventions | 2 |
| R4 | `sys` + `no_object` | incompatible; explicit `compile_error!` | accepted D10 and ticket06 | 2 |
| R5 | `type_of` on `Child` | `"Child"` | Rhai time tests | 2 |
| R6 | `metadata` feature | doc-comments on every function render | Rhai conventions | 4 |
| R7 | `try { ... } catch (e)` around a denied call | `e` is a `SysError`; `e.kind` is the variant name, `e.message` starts with it, `e.io_kind` names the `io::ErrorKind` for I/O errors, and the script continues after the catch | D5 | 1 |

## 5. Test infrastructure

The fixture design is retained. Earlier Wine/install and CI proposals below are
historical; the native, no-install and disabled-Actions constraints in the accepted
release contract and current section6 govern future execution.

- Files: `tests/sys_policy.rs`, `tests/sys_env.rs`, `tests/sys_fs.rs`, `tests/sys_process.rs`,
  each starting with `#![cfg(feature = "sys")]`, following the existing `tests/time.rs` style.
- Fixture process: no separate binary. The process test binary re-executes itself via
  `std::env::current_exe()` with `--exact sys_fixture_entry --nocapture` and an environment
  variable `RHAI_SYS_FIXTURE=<mode>`. The `sys_fixture_entry` test function checks that variable
  and, when set, behaves as the fixture (echo argv as JSON lines, echo stdin, print env, write
  N bytes to both streams, sleep, exit with a code, or raise a signal on Unix) and exits. When
  the variable is unset it returns immediately, so normal test runs are unaffected. This is the
  pattern Rust's own `std::process` tests and `assert_cmd` use; it works under plain
  `cargo test` on every platform.
- Temporary directories: `std::env::temp_dir()` joined with the crate name, process id and an
  atomic counter. Cleaned up by a guard struct on drop. No `tempfile` dependency.
- Platform gating: Unix-only rows use `#[cfg(unix)]`, Windows-only rows `#[cfg(windows)]`.
  Every row runs on at least one CI OS.
- Windows without a Windows machine: the suite runs under Wine. Verified on 2026-09-29 with
  Wine 9 on Linux: 43 of 43 tests pass, the same as natively on Linux. Wine needs a UTF-8
  locale, otherwise non-ASCII file names fail with `NotFound`.

  ```bash
  rustup target add x86_64-pc-windows-gnu
  apt-get install -y --no-install-recommends wine64 gcc-mingw-w64-x86-64
  export WINEDEBUG=-all WINEPREFIX=/tmp/rhai-wine LANG=C.UTF-8 LC_ALL=C.UTF-8
  cargo test --features testing-environ,sys --target x86_64-pc-windows-gnu --no-run \
      --test sys_policy --test sys_env --test sys_fs
  for exe in target/x86_64-pc-windows-gnu/debug/deps/sys_*.exe; do wine64 "$exe"; done
  ```

  Wine is a check, not proof: quoting of process arguments and `cmd.exe` behaviour in
  phase 2 and 3 still need one run on real Windows via the CI matrix.
- CI: `.github/workflows/build.yml` gains matrix rows
  `--features testing-environ,sys` and `--features testing-environ,sys,sync,no_index` on
  ubuntu, plus `--features sys` on the existing windows and macos jobs. The wasm32 rows
  must not include `sys`.

## 6. Remaining acceptance plan — revised 2026-10-07

**Current execution plan.** The owner explicitly resumed implementation after this
plan was revised. Package A is complete at its recorded Linux/Rust 1.77.2 scope;
Package B remains open after its documented infrastructure stops; its required
criterion map is now complete. Package E's one bounded Expert24 follow-up has
ended in a confirmed launcher infrastructure failure before Cargo/assertions. Its
route is stopped with three infrastructure allocations, zero assertions and zero
product corrections. Packages B–F and release acceptance remain open.
This section is the single current plan; the campaign state records evidence and
ownership. Historical estimates do not allocate retries or certify completion.

### 6.1 Applicable rules and historical investigation

Current central repository: `/Users/hoppworks/projects/agent-skills`, inspected HEAD
`14617043b70d1ba2d40b720832cbad294fa8c008`. No newer revision was explicitly pinned
for this request. Loaded the actual `config/common/AGENTS.md`, this worktree's
`AGENTS.md`, `skills/campaign/SKILL.md`, its `references/repair-package.md`,
`skills/e2e-proof/SKILL.md`, `skills/wayfinder/SKILL.md`,
`skills/ocr-delegate/SKILL.md` and `vendor/mattpocock--skills/tdd/SKILL.md`.
The central repository has no tracked modifications. Its untracked paths are
`.scratch/acceptance-overhead-plan-20261006/`, `build-age-automation-update.json`,
`campaign-calibration-budgets/`, `campaign-repair-packages/`, `central-build-paths/`,
`container-cleanup-automation-update.json`, `disk-pressure-cleanup-20261007/`,
`harness-efficiency-20261003/`, `machine-heavy-runs-20261004/`,
`owned-resource-cleanup/`, `periodic-sync/` and `streamline-acceptance/`, all below
`.scratch/`. These are not installed instructions. No installation, sync or Agent
configuration change was made. Other Sessions' loaded revisions are unverified;
no other Session was resumed or messaged for this planning request.

Compared with the previous campaign revision `6830c49ed962a3dc1937d72d0d182150bb4c935c`:

| Area | Applicable consequence for the open plan |
|---|---|
| Authorization and repairs | The owner's current instruction resumes the authorized implementation. Preserve consumed corrections and explicit finite actions; agent estimates and obsolete PENDING labels are not new approval gates. Reconcile existing human instructions before any later missing-authorization claim. |
| Review and delegation | One combined independent review per coherent change package, with affected-delta checks and evidence readback; specialist review only for a named risk. Keep related repairs with one responsible context. |
| Build/proof reuse | Reuse unchanged, applicable proof. Prefer related commands in one bounded build. Exceptional finite retention must be selected and recorded before use, with exact ownership, inputs, expiry and reuse boundary; a historical path or image ID is insufficient provenance. |
| Resource lifetime | Check free bytes on actual output/cache filesystems against additional occupancy and binding reserves. Recover storage only from proven own obsolete resources. Separate immutable builds from mutable fixtures; export before exact cleanup. |
| Acceptance/state | Validate the complete real entry/input/transport/export/consumer path before expensive execution. Record product RED, product failure and infrastructure abort separately. No new wrapper framework or repeated status hierarchy. |

The expired project concurrency exceptions do not reopen their named invocations.
The current global ceiling is one heavy run on MacBook and up to three on workhorse
or lllm, subject to measured pressure and stricter package conditions. The existing
first-cause guard's zero-foreign-heavy condition is conservative and retained until
an explicitly reviewed change; it does not prove a slot is reserved. The package's
600/585/540-second limits, two Cargo jobs, 16 descendants, 1,572,864 KiB storage
preemption, 2,097,152 KiB hard storage/RSS and 16 GiB admission reserves remain.
No unresolved rule conflict requires an outcome change. Stopped repair routes
below remain stopped; the new rules do not reset their history.

Read in full:
`/Users/hoppworks/Documents/Codex/2026-10-06/codex-threads-01a0fe32-5425-71d2-887b/outputs/session-review-2026-10-06.md`.
It describes four Tauron Sessions, not this Rhai Session. Its SQLx, UI, transport and
AUTHZ diagnoses are not Rhai findings. The useful hypotheses were checked here:
complete producer/consumer preflight, fewer handoffs, unchanged-proof reuse and
real acceptance. No Tauron test counts or failure causes are imported.

### 6.2 Reconstructed state and immediate bottleneck

The detailed first-cause attempt narrative in this subsection is a historical
snapshot from before native allocation 4. Its present-tense wording describes that
earlier point in time; Package A's completed status and accepted evidence are
recorded in 6.3 and 6.6 below. Do not treat its old staged wrapper or source pins as
the current next action.

Coordinator HEAD is `8e5fe089fbcc86979ed3d5b73c393bf8fec72150` in
`/Users/hoppworks/projects/rhai/.worktrees/all-tickets-environment-recovery`.
All six local decision tickets are resolved as specifications. Feature completion
and release acceptance remain open. Existing filesystem/environment/file-handle/TCP
proof, core Darwin Rust 1.66 Engine proof, optional compiler/nonprocess feature
proof and named Linux lifecycle/example proofs remain accepted only within their
recorded source, assertion, toolchain and platform applicability. Compilation,
older native Windows 45-test proof and Wine do not close current process/TCP release
acceptance. No fresh remote-head claim is made by this implementation continuation.

The current first-cause writer is
`/Users/hoppworks/projects/rhai/.worktrees/process-first-cause`, HEAD
`77149f19e017007281396dcbf2eb8e69b7b90a37`, with preserved dirty source/recipe
corrections and untracked staging/collector files. The production fix remains
unapplied. Native allocation 1 was admitted at 2026-10-07T06:47:41Z and reached
`baseline-red-direct`, but rustc stopped before any product assertion with E0308
at `src/packages/sys/process/unix.rs:4703`: the test adapter parsed PGID as `u32`
while the observed value is `i32`. The helper's missing raw-child receipt follows
from that compile abort; the later `/proc` diagnostic is secondary. This is a
fixture compilation failure, not a meaningful RED or completed failed product
correction. Its original output, allocation and cleanup receipts are preserved in
the writer's `attempts/attempt-01/`; the exact stage was retired after checking 72
PID/start identities and both owned groups, and the private scope is absent.

The one-line test-adapter correction parses PGID as `i32`; the production patch
remains unapplied. Attempt 2 used the reviewed stage and fresh admission at
2026-10-07T07:09:25Z (no heavy process; 81,014,168 KiB MemAvailable and
610,395,287,552 free bytes). Its exact `baseline-red-direct` command compiled
under Rust 1.77.2 and exited 101 at the intended public assertion: actual cause
was `OutputLimit("decoded process output exceeded the engine string limit of 512 bytes")`,
expected cause was `OutputLimit("stdout for `/usr/bin/python3` exceeded max_output of 512 bytes")`.
The stdout receipt independently confirms the child committed stdout overflow,
then observed stderr overflow and reaped the child. This is a meaningful product
RED and partial lifecycle proof. The producer then rejected the receipt because
libtest prefixes the selected test name on that same line; the helper exited 1
before the other five controls. No GREEN, mutant control, package acceptance or
production fix is claimed. The later `/proc/<pid>/stat` notice was a secondary
child-exit polling race; runtime and scope cleanup/readback both succeeded.

All 34 files from attempt-2 `proof-evidence` and `outer-evidence` were copied to
the writer and matched against fresh Workhorse SHA-256 readback. Exact originals
are under the writer's `attempts/attempt-02/`; no compiled artifact remains.
Local test-first probes now exercise exact selected-test receipt binding,
duplicate rejection, the split libtest `receipt\nok` / `receipt\nFAILED` status,
and missing/wrong statuses. The actual attempt-2 RED is accepted by producer,
collector and closure parsers. The same combined reviewer initially found the
GREEN status parser still expected contiguous `... ok`; that was fixed in the
same batch. The affected re-review returned READY. See
[the review history](../.scratch/all-tickets/process-first-cause-review.md) and
the current session state for exact evidence and consumed-work history.

Attempt 3 used the first parser-fixed stage and a fresh admission at
2026-10-07T07:36:39Z. Its 16 staged pins and wrapper/guard inputs were verified;
fresh admission found no heavy run, 81,120,748 KiB MemAvailable and
610,376,998,912 free bytes. Four controls—baseline RED and overwrite-mutant RED
for DirectChild and Managed—exited at the intended public cause assertion. The
DirectChild restored GREEN then reached the committed-cause, cached-result,
stdout/stderr byte, child-lifecycle and empty-cleanup-diagnostic assertions. It
stopped at the final completion-flag assertion because this exiting child had
reached EOF on both captured streams. The test's expectation of incomplete
streams was invalid; the corrected assertion now requires both streams complete.
The Managed restored GREEN was not reached. The combined reviewer rechecked this
test correction and returned READY. The exact test-only adapter changed after
attempt 3, so its stage is stale for the next run.

All 49 attempt-3 evidence files were copied and SHA-256 matched locally. A fresh
read-only closure confirmed all 120 recorded PID/start identities were absent or
reused, both owned process groups were empty, and the runtime scope and private
runtime were absent. No compiled artifact remains. Cumulative native allocations
are three; attempt 1 was a pre-assertion fixture compile failure, attempt 2 a
valid RED followed by a parser infrastructure stop, and attempt 3 four valid
REDs plus a restored-GREEN test assertion failure after the product assertions
passed. This last failure is a test correction, not evidence that the production
fix failed. Preserve all unaffected RED proof and partial OS evidence; no
full acceptance is claimed.

### 6.3 Open packages and observable exits

Packages are acceptance groups inside the existing tickets, not new tickets or
Sessions. Each may record partial criterion closures. They share the evidence and
resource rules in 6.4–6.6; no row is done merely because this plan names it.

| Package | Observable exit and dependencies | Cheap preflight and existing route | Real evidence, review and reuse |
|---|---|---|---|
| A. Committed Child cause | DirectChild and Managed retain the first actually committed stdout cause after gated stderr overflow/lossy expansion; cached results, captured bytes/EOF and cleanup agree. | Complete in native allocation 4 using the existing bounded six-control invocation: baseline RED and overwrite-mutant RED in both modes, followed by restored GREEN in both modes. All six expected statuses and assertions passed at one archive. The baseline fix's current source hash matches the tested GREEN phase. Combined independent review returned READY. | Original proof, source-phase hashes, child acknowledgments/argv/PID/start/group, captured bytes/EOF, lifecycle and cleanup receipts, independent identity/group/path closure, and custody/readback receipts are preserved under `../.scratch/all-tickets/process-first-cause-evidence/originals/`. 127 process identities, five owned groups and six paths were independently checked; stage and runtime are absent. The exact tested source change is implemented in the writer worktree. This closes Package A only for Linux/Rust 1.77.2; it does not close ticket 03 or other platform/features. Preserve accepted overlap/setup/performance proof. |
| B. Remaining process terminal/cancellation semantics | First committed cause survives secondary cleanup; no-primary guard still reports the correct cause; stdin early close, cached wait/try_wait/kill, capture flags, owner/sentinel survival and bounded reaping meet ticket 03. Depends on A for the same Child capture path; stdin can be diagnosed independently. | A focused public-Engine Child.wait regression for no-primary decoded-output expansion is source-pinned and its affected review is READY, but its assertion has not executed. The last bounded Workhorse invocation exited at run.sh line 4 because the launcher omitted required SESSION_SCOPE; Rustup/Cargo/tests did not start. This is infrastructure, not RED or product failure. Preserve three Package B launches / three infrastructure stops / zero assertions. The one post-escalation follow-up is consumed; do not retry this path or use native110. | package-b-child-wait-01/attempt-03/outcome.json preserves outer logs and readback hashes; the private runtime and exact remote scope were cleaned. The named no-primary behavior remains unaccepted. The criterion map in 6.7 records exact test/proof applicability and gaps; do not retry the stopped path or use native110. Other open stdin, cache, cancellation, capture, owner/sentinel and bounded-reap cases remain open where no applicable accepted proof exists. One combined lifecycle review per affected implementation; preserve accepted Linux controls. |
| C. Darwin native completion | Missing macOS lifecycle, process behavior and sys/net real examples/feature interactions pass on native Darwin at the selected Rust version. Depends on a proven custody/readback path; no dependence on re-running Linux foundations. | Compare current sources and selected dependency/tool graph with existing compiler/sys/net proof. Existing `.scratch/all-tickets/macos-process-overhead.py` and `darwin-process-reader.py` are the nominated path; verify all actual paths/imports/SDK/tool versions and original stdout grammar before a native launch. Old source pins and Expert09/12 failed follow-ups are not ready execution. | Public Engine, actual child/group state, independent native reader, TCP peer and file readback where applicable; intact host/sentinel. One combined review of changed custody plus affected behavior. Reuse compiler/nonprocess/EPERM proof where unchanged. Earlier overhead method measures API-entry-to-report, not spawn-to-first-byte; do not repeat a fulfilled measurement merely for a new plan. |
| D. Windows custody then native behavior | Exact owned job survives connection loss under an independent lease/monitor, bounds work, reports truthful nonzero failure and exports/cleans; then native sys/process/net and quoting/policy/feature criteria pass. Custody is a prerequisite with its own partial exit. | Existing `windows-runner-gate.md`, Windows scoped-runner brief, Expert02/13 and `windows-resume-20261003/harness-command.txt` are the canonical design/history. Before compiler use, check the full console/client/job/status/export path. Current self-inclusive teardown has a source-supported failure-status explanation, not proven kernel causation. Preserve exhausted two harness attempts; no automatic third. | Native setup-failure, real 0/17, mismatch/restored, interrupted connection/supervisor, exact job membership/closure and retained primary diagnostics. Observer stays outside the failed job. Then real Engine, actual filesystem/TCP peer/process readback. One combined package review, extra Windows specialist only for a named unresolved job risk. Preserve installation/activation/native baseline and backups; never drive the other Session's guest. |
| E. API metadata and usable documentation | Registered receiver/arity/type/doc-comments match actual Engine metadata; sys/net/process examples run with independent effects; public config/error compatibility and file API divergences are documented. | Existing API candidate09eb is rejected because `local_addr` selects `NetStream` instead of exported `NetListener`; working assertions include the receiver correction but remain unverified. Native3 consumed three allocations and stopped before assertions: allocation 1 reached Cargo compilation but failed because `build.template` was absent; allocation 2 stopped before Cargo because the staged filename mismatched; allocation 3 stopped before Cargo because the archive-member check pipeline exited 141 under `pipefail` after `grep -q` closed tar's pipe. Zero assertions and zero product corrections. Escalation 24's sole follow-up and stop condition are exhausted; no further Package E build may use this route. The final launcher/preflight and direct pipeline/no-op evidence are under `api-metadata-evidence/native3-20261007/attempt-03/`. Preserve Expert21 and the full open acceptance scope. | Still requires actual generated metadata through Engine, intended assertion RED/restored GREEN, and native examples with file/peer/child readback. One combined API/docs review at the eventual corrected package baseline; share changed metadata/example rows with F. Reuse accepted Linux examples where source/expectations remain unchanged. No new metadata normalization layer or unrelated prose sweep. |
| F. Integrated compatibility/release closure | Every ticket criterion has applicable proof at the integrated revision: core1.66, optional1.77.2, native Linux/macOS/Windows, required semantic feature rows and explicit unsupported combinations. Depends only on relevant A–E criteria, not all preparation steps indiscriminately. | Diff source/assertions/manifests/lock/toolchain/config against existing accepted rows. Use project Cargo integration targets and the exact approved feature matrix in ticket06/release-proposal.md. Resolve actual archive inventory/tool availability/paths and expected error categories before compiling. | Share one build and real acceptance for related rows per machine/toolchain/feature identity. Reuse unaffected rows; rerun only changed dependency closures. Default sys/net and sync/no_index, metadata+serde/i32, unchecked/no_index/sync/metadata/f32 interactions remain covered. Core without OS deps; sys rejects no_std/no_object/WASM as decided. Combined integrated review/readback closes each criterion, not a count-only gate. Release readiness does not authorize publishing, deploying or enabling Actions. |

No UI is part of Rhai's acceptance stack. The full path is script → real Engine →
host package → OS. Storage proof is required for filesystem effects; independent
peers and process observations replace storage writes for networking/process
behavior. Read-only APIs compare independent truth. A mock or compiler success
cannot replace these checks.

### 6.4 Concrete command contract and current execution

All paths below were read. The attempt-3 producer, collector and closure parsed
the libtest-selected receipt and separate `ok`/`FAILED` result. Attempt 3
provided four expected RED controls and a DirectChild restored-GREEN partial
result. Attempt 4 used the corrected source and passed all six controls; its
original outputs and exact phase hashes are preserved. The combined independent
review and custody/readback checks are complete. Other proposed commands remain
unexecuted until their inputs are frozen.
POSIX commands run from an owned source copy within the existing bounded runner,
not the coordinator's mutable source. Project ID is `rhai`. The invocation creates
one unique owned absolute session scope and uses its path as `TMPDIR` for
`/Users/hoppworks/projects/agent-skills/tools/run_scoped.py --timeout <bound> -- <command>`.
Inside it set target/private Cargo and Python caches to `AGENT_RUNTIME_DIR`, using
`CARGO_TARGET_DIR`, `CARGO_HOME`, `PYTHONPYCACHEPREFIX` (or disable bytecode) and the
recipe's private `RUSTUP_HOME`. Direct Rust/Cargo paths must match the intended
1.66 or 1.77.2 version; `stable` is not a substitute.

For A, the existing native argument shape is:

```text
<private Rust1.77.2 cargo> test --locked --lib --features testing-environ,sys   packages::sys::process::unix::tests::committed_stdout_cause_survives_stderr_overflow_direct_child   -- --exact --nocapture --test-threads=1
```

The second exact test ends in `_managed`. The recipe executes four intended REDs
and two restored GREENs in one bounded runtime, preserving phase hashes and raw
receipts. Attempt 1 failed during fixture compilation before assertion; attempt 2
reached the expected baseline RED, then its producer stopped before the remaining
five controls because the receipt parser did not accept the observed libtest
output. Attempt 3 passed four RED controls. DirectChild restored GREEN reached
the cause, cached-result, output-byte and child-lifecycle assertions, then stopped
at the stale EOF assertion; the following cleanup-diagnostics assertion was not
reached. The reviewed correction now requires both streams complete after child
exit.
Preserve the 49 hash-matched attempt-3 files and independent closure as partial
proof. Attempt 4 passed the complete six-control set at one exact archive, so no
selective cross-run aggregation or additional acceptance runner was needed. The
phase hashes show the production fix in both restored-GREEN cases and the
baseline restored after the mutant. The exact stage and private runtime were
retired only after evidence export, independent readback and closure.

The accepted project baseline route remains:
`cargo test --locked --features testing-environ,sys,metadata --test sys_policy --test sys_env --test sys_fs`.
Add existing `sys_process`/net integration targets according to covered criteria,
not a fabricated universal command. E's existing recipe selects
`cargo test --locked --features testing-environ,sys,net,metadata --test <target> metadata -- --nocapture --test-threads=1`.
Its old mutable stable/pin/receiver assumptions must be corrected before use.
Windows has a design and recorded console command, not a proven executable
release runner; no POSIX SSH wrapper can establish guest cleanup by itself.

### 6.5 Evidence, actual artifact availability and lifecycle

Read-only existence checks on 2026-10-07:

| Resource | Actual availability and permitted reuse |
|---|---|
| Committed originals in this coordinator worktree | Overlap raw result/restoration/control ledgers and independent closure are present: source9dc, controls101/101 then0/0. Post-spawn setup originals are present: source523, wrong-cause101/wrong-completion101/restored0. These narrow accepted results remain proof, not new acceptance claims from producer acceptance_claim=false. |
| Overlap workhorse stage/scope | Exact `/root/rhai-linux-process-overlap-d79-20261004-1259` and its central scope are absent, including symlink checks. No reusable compiled build remains there. |
| First-cause attempt 1 | Original compile failure, raw diagnostics and allocation receipt remain under the writer's `attempts/attempt-01/`. The exact remote stage was independently retired; 72 PID/start identities and both owned groups were checked, scope is absent, and there is no reusable compiled output. One native allocation is consumed. |
| First-cause attempt 2 | Its stale stage was retired after attempt-3 stage readback; original partial proof is under the writer's `attempts/attempt-02/`, with 34 files hash-matched locally. It contains one valid baseline RED and process receipt, not full acceptance. |
| First-cause attempt 3 | Partial evidence is under the writer's `attempts/attempt-03/`; 49 files match Workhorse SHA-256 readback. Four expected REDs are valid. DirectChild restored GREEN reached the cause, cached-result, output-byte and child-lifecycle assertions, then failed at the old EOF assertion; the following cleanup-diagnostics assertion was not reached, and Managed GREEN did not run. Fresh closure verified 120 identities absent or reused, two owned groups empty and the private scope/runtime absent. Exact stale stage `parserfix-01` was retired at 2026-10-07T07:55:26Z after checking 120 PID/start identities and empty groups; the receipt also confirms scope absence. |
| First-cause attempt 4 | Complete originals are preserved under `../.scratch/all-tickets/process-first-cause-evidence/originals/stage-originals/proof-evidence/`, with outer custody and independent-closure receipts under `../.scratch/all-tickets/process-first-cause-evidence/originals/`. Four intended RED controls exited 101 at the first-cause assertion; both restored GREEN controls exited 0 and independently read back one passed test. The phase source hash is `fced800d5b05a1582a4d1c27cadabda32dc1517522e5ed733865d7faab48e5d4`; final baseline restoration matched. Resource samples (54 periodic samples) recorded maxima 950,608 KiB RSS, 697,712 KiB storage and four descendants, below the recorded limits; these are sampled, not continuous peaks. Independent closure verified 127 identities, five owned groups and six paths. The exact stage, scope and private runtime are absent. No compiled artifact is reusable. |
| First-cause stage | The `parserfix-02` stage was consumed by attempt 4, then independently read back and retired after preserving proof. It is absent at `/var/roothome/rhai-linux-process-first-cause-01a0f114-20261007-parserfix-02`; the central private scope and runner runtime are also absent. Do not reuse historical stage paths or claim a reusable build. |
| Core private builds | All four paths in `core-current-msrv-root-readback.json` are still absent locally. Logs/control/restoration proof remains; no compiled-target reuse claim. |
| macOS locked source audit | Historical source-integrity receipt remains, but its exact `macos-overhead-safeguards/.../macos-overhead-custody-source-audit` path is absent. Restore only required source inputs from verified surviving archives or acquire needed inputs later; do not claim the old 131-archive tree is available. |
| Windows baseline/images | Read-only host listing confirms `/var/lib/libvirt/images/rhai-win11-quality` with system.qcow2, baseline and ready-baseline. Existence does not establish source/toolchain provenance or guest cache availability. Guest paths were not queried and remain unconfirmed; preserve this other owner's resources and snapshots. |

There is no currently verified reusable owned compiled build. Prefer build/test/
readback/export in the same invocation. Do not rebuild an unchanged artifact for
an assertion-only control: reset uniquely owned fixture data separately. If a later
package genuinely needs finite retained compilation, record exact central path,
owner, input identity (sources, lock, toolchain, flags, SDK), byte ceiling, finite
reuse boundary and expiry before configuring output outside the runner's private
runtime. No exceptional retained build is allocated for package A.

Before a heavy launch, measure free bytes on source/output/cache filesystems,
active machine-wide runs and available RAM against the preserved limits/reserves.
For each actual filesystem, require free bytes minus predicted additional occupancy
to retain the binding16 GiB reserve; budget private output up to its2 GiB hard ceiling
plus measured stage/export occupancy rather than treating16 GiB free as unlimited
build space. No new retention size is allocated.
Historical samples do not establish peaks or current slots. On insufficient disk,
export proof and perform one bounded cleanup of exact obsolete own resources,
recheck free bytes, then continue only if feasible. No broad cache purge, foreign
stop, VM reset, worktree removal or install follows from this plan.

Save source/lock/tool versions, raw stdout/stderr/status, phase identities, resource
samples, partial results and diagnostics outside private runtimes as they complete.
Independently read back actual effects and exact cleanup. Separate diagnostic
collection on failed/partial runs from the success-only acceptance validator.
Only then retire exact inactive own stage/runtime/containers and empty scope;
Windows cleanup requires job/monitor ownership. Durable proof and foreign assets
are preserved. Attempt 1's exact owned stage was retired after proof preservation.
Attempt 2's partial proof has been copied and hash-checked locally; its exact stale
stage was retired after the initial byte-level `parserfix-02` readback. A semantic
audit then found the generated preflight's mismatched physical-stage assertion.
The test caught this first as an expected local RED; after fixing the physical path
mapping, the full recipe probes passed and the combined review returned READY. The
old preflight and first receipt are retained; the corrected guard was read back
with the other 18 stage files. No run or compiled artifact was created. No foreign
or shared resource was cleaned. At this historical checkpoint Tauron Integration
reported its selftest green and was checking cleanup; the latest Workhorse process
listing showed no heavy process. The earlier authorized build-window request was
subsequently resolved: Tauron was informed that Rhai's run had ended and its slot
was available for Tauron's own fresh admission (see the later Package E record).
Do not wait for the old signal; any future launch still needs fresh admission.

### 6.6 Retry triggers, risk and critical path

Critical path: Package A is accepted only at Linux/Rust 1.77.2 → Packages B and E
remain open with their current bounded routes stopped; C and D retain unproven
custody prerequisites → select an independently open requirement with an unspent
route before any further heavy run → close only uncovered integrated rows in F →
verified fork-main integration under existing Git authorization. No upstream
writes, production release or new Goal are authorized.
Do not repeat Package A's build or six controls. Its accepted proof is tied to the
tested source/lock/toolchain and Linux environment recorded in the preserved
receipts. A later A rerun needs a relevant source, assertion, dependency, toolchain
or environment change that invalidates this proof, or a specific uncovered A
criterion. A new Session, rule revision or renamed cause is insufficient.
For Package B, first map the still-open ticket 03 criteria to existing code and
original evidence; run the cheapest source/test-target checks before selecting one
real-OS case for any genuinely uncovered behavior. A further expensive run needs
a new product diagnosis/fix, changed relevant inputs or an uncovered acceptance
criterion; do not respond to a new failure with a routine full-suite rerun or a
new transport/wrapper layer.
After repeated preparation failure inspect the entire actual composed path before
allocation; do not append another transport/wrapper layer or rerun all packages.
Expected assertion RED consumes its allocated command but is not a failed product
correction. Compiler/parser/export aborts before assertions are infrastructure
outcomes. Completed rejected repairs retain their cause counts. Two failed
corrections/recoveries require the prescribed independent diagnosis; exhausted
post-escalation follow-ups stop that route. No routine approval gates are added.

Preserved stopped paths: stdin Expert18 (two failed corrections plus rejected sole
follow-up2518238; native110 unallocated), Darwin custody Expert09/12, metadata
Expert21 (two corrections plus rejected09eb follow-up) and Windows Expert02/13
(two harness invocations consumed; real-client finite30-minute boundary unchanged).
The task's standing acceptance of recommendations must be reconciled with the
specific human limits before any later authorization conclusion. It cannot erase
consumption or authorize a third run by renaming a cause. These are open execution
risks, not reopened allowances or dropped acceptance criteria. A simpler route must
retain the same observation/custody contract and explain why it avoids the proven
failure mechanism; this plan does not assert such a route is already proven.

Risks/counterarguments: A's accepted proof is narrow to its exact Linux/Rust
1.77.2 source, lock and assertions; it does not prove B's other process semantics
or Darwin/Windows behavior. Shared builds save setup only when inputs match;
platform-specific cleanup cannot transfer from Linux to Windows. Package A's
combined reviewer returned READY; Windows guest ownership remains with its
recorded owner.
The current task has no unresolved result/design choice requiring a user answer.
Implementation feasibility of stopped routes remains explicit, not certified.

**Current next action:** Package B's Ticket03 map in 6.7 remains an applicability
map, not acceptance; its named no-primary behavior and other open rows remain
unproven, and its three-launch route is stopped. Package E's metadata tests also
remain unverified, and its route is stopped after allocation 3. Preserve every
criterion and all consumed counts. The next execution must select an independently
open requirement with an unspent route; no Package E or Package B rebuild follows
from this status update. This is not a new approval gate or a declaration that the
remaining tickets are infeasible.

The exact metadata command and its source/test mapping remain as recorded below.
The full archive and pinned lock provenance remain available locally; the attempt-03
preflight passed, then the launcher stopped at line 23 before extraction/Cargo due
to the `tar | grep -q` pipefail interaction. See the attempt-03 classification and
readback files. No metadata criterion, runnable example, OS effect, compatibility
row or release gate is closed by this attempt.

The exact command is
`cargo test --locked --features testing-environ,sys,net,metadata --test net_metadata --test sys_policy metadata -- --nocapture --test-threads=1`.
It selects `metadata_exposes_the_documented_tcp_surface` and
`metadata_documents_tcp_handle_operations_and_overloads` in
`tests/net_metadata.rs`, which register `NetPackage` in a real `Engine`, serialize
`gen_fn_metadata_to_json(false)`, and check exported TCP comments and signatures;
it also selects `test_function_metadata` in `tests/sys_policy.rs`, which builds
the sys `Engine` metadata and checks `SysError`/Unix `Child` comments and the exact
Child signatures. Thus this start path reaches the registered public metadata
criterion. It does not exercise socket, process or file effects and cannot close
Package E's example/readback requirements.

The following allocation1/allocation2 detail is historical and is superseded by
the terminal allocation3 outcome and current next action above.

Native3 allocation1 reached Cargo compilation but stopped before assertions because
its staged source archive (SHA-256
`c34c9b889a1e9b4052f9c52b8256d6d7236b92baffdfc26784d1442fdc6381af`) omitted
tracked `build.template`; allocation2 stopped before Cargo because the
launcher expected `source.tar.gz` while the complete archive was staged as
`source-full.tar.gz`. Both are infrastructure outcomes in the unverified source
handoff path, not RED or product corrections. Cumulative native3 counts are two
allocations, two pre-Cargo/pre-assertion stops, zero assertions and zero product
corrections. Allocation2's raw outputs, input hashes and postrun scope/runtime
readback are under `.scratch/all-tickets/api-metadata-evidence/native3-20261007/attempt-02/`.
The exact owned staging files and empty scope were removed after preserving proof;
no compiled artifact is reusable. The full replacement source archive is
`.scratch/all-tickets/api-metadata-evidence/native3-20261007/source-full.tar.gz`
(422 current tracked inputs, SHA-256
`a243fc96c513c70d86e0281e0f178d91c95e6338ab3dda24d1656f7dd8863de5`); the archive
and each entry were checked against this worktree. Its pinned lock is
`.scratch/all-tickets/api-metadata-evidence/native3-20261007/Cargo.lock`
(SHA-256 `4ff0a7de6f504510af64092d446d411b86d95228b23a188b396bd188da367627`). The
corrected bounded launcher is
`.scratch/all-tickets/api-metadata-evidence/native3-20261007/run-recovery-red.sh`;
it validates both hashes and `build.template`, uses Rust 1.93.0 and `--locked`,
and preserves logs outside the runner's private runtime. Dependencies are the
exact complete archive/lock, the installed pinned Workhorse toolchain and runner,
at least the project admission reserves on the actual filesystem, and an available
heavy-run slot. The prior Tauron Cargo/rustc group ended; Workhorse's read-only
process/capacity snapshot at 2026-10-07T09:56:49Z found no active scoped
runner/compiler, 80,850,876 KiB MemAvailable and 610,347,319,296 bytes free on
the output filesystem. The owner-authorized message informed Tauron that Rhai is
terminal and its run slot is free; Tauron may proceed only under its own fresh
admission. That snapshot is not a slot reservation. The corrected launcher
samples the exact helper process tree and private runtime once per second,
records maxima and stops at the existing 16-descendant, 1,572,864 KiB
storage-preemption and 2,097,152 KiB RSS/storage thresholds. Its 510-second work
deadline leaves the existing 30-second reserve inside the 540-second helper cap;
the scoped-runner and outer bounds are 585 and 600 seconds. Sampling reports
bounded maxima, not continuous peaks. Guard/setup failures remain infrastructure
outcomes, separate from metadata assertion RED.

Escalation 24 asks for a read-only review of the complete archive-to-stage-to-
launcher path and a single minimal repair/preflight. It does not authorize another
wrapper, Cargo run during diagnosis, or product edit. After that bounded repair,
recheck exact names and hashes, the launcher/runner/toolchain, process absence,
Workhorse capacity and slot, then coordinate Tauron's own admission before one
bounded metadata run. Only a named missing/inadequate metadata assertion is RED;
another setup stop ends this route for diagnosis. After valid RED, make the
smallest accurate documentation correction and rerun only affected metadata
tests. Capture Engine JSON and exact test output, then perform one combined review.
This closes only the metadata assertions; Package E still needs runnable examples
with independent file/peer/child readback and the remaining compatibility/docs
criteria. Keep Expert21 and all native history unchanged; no full matrix or
unrelated rebuild is implied.

### 6.7 Ticket 03 criterion-to-evidence map — checked 2026-10-07

This map compares original requirements P2/P10/P11/P13 and X1–X38 with current
test source and accepted proof artifacts. “Accepted” means only the named Linux
cases and rows below; “partial” preserves the stated gap. No row is closed by a
source test alone or by an unreviewed/provisional result.

| ID | Current test/evidence | Applicability and remaining gap |
|---|---|---|
| P2 | `tests/sys_policy.rs`; no default-process test | Open: default Engine `run` denial and independent no-child observation are not covered. |
| P10 | `ProgramPolicy` predicate tests in `tests/sys_policy.rs` | Open: no public Engine denied invocation with proof that no child was created. |
| P11 | `process_cwd_uses_the_opened_filesystem_capability_after_root_replacement`; `linux-process-options-proof.md` | Partial: Linux capability-held cwd and denied symlink escape are accepted in named rows; escape denial proves no fixture record, not absence of every transient process, and does not cover every outside-root cwd form. |
| P13 | `tests/sys_process_windows.rs` | Open: existing Windows test covers raw output/nonzero exit, not default `.bat`/`.cmd` denial. |
| X1 | `scalar_run_with_cwd_works_without_collections`; `linux-scalar-process-proof.md` | Accepted for named Linux feature rows: public Engine success, exit 0 and independent child record; no wider matrix follows. |
| X2 | No matching test in current `tests/sys_process.rs` | Open: missing program must yield NotFound and no child. |
| X3 | `run_raw_captures_exact_stream_bytes_and_nonzero_exit_as_data`; `linux-process-options-proof.md` | Accepted for named Linux rows: exit 0/7 and exact raw bytes as result data. |
| X4 | No exact-argv assertion identified | Open: spaces and quotes must round-trip exactly. |
| X5 | No literal shell-metacharacter assertion identified | Open: `$HOME`, `|`, `;`, and `&&` must reach the fixture unchanged. |
| X6 | No empty-argv assertion identified | Open: an empty argument must be preserved. |
| X7 | `scalar_run_with_cwd_works_without_collections`; options proof | Accepted for named Linux rows: valid cwd is observed through child output and independent host readback. |
| X8 | No missing-cwd test identified | Open: failure must be NotFound with no child. |
| X9 | Scalar process proof records explicit `RECORD` override | Accepted for named Linux rows; other platform/feature combinations remain open. |
| X10 | Scalar process proof uses `env_clear` and explicit override | Accepted for named Linux rows; does not imply every environment edge case. |
| X11 | No exact `env_remove` child assertion identified | Open: removed variable must be absent in the child. |
| X12 | Raw capture and options proof | Accepted for named Linux rows: stdout and stderr are separately observed. |
| X13 | `process_supervisor_handles_large_simultaneous_io_and_exact_per_stream_caps`; `linux-process-io-proof.md` | Accepted only for the two sensitivity-backed Linux claims and recorded feature rows; not a complete IO or platform matrix. |
| X14 | No dedicated ordinary empty-output test identified | Open: zero-cap silent output is a different branch. |
| X15 | Raw capture/options proof | Accepted for named Linux rows: exact raw bytes and lossy text behavior, including nonzero exit. |
| X16 | Shared-child proof exercises large `spawn` stdin; no `run` string-echo test | Open: spawned stdin count/readback does not prove `run` string round-trip. |
| X17 | No 1 MiB `run` blob round-trip test identified | Open: exact input/output and concurrent child output remain unproven. |
| X18 | `unit_stdin_means_immediate_eof`; options proof | Accepted for named Linux rows: unit stdin produces EOF; other feature/platform rows remain open. |
| X19 | Deadline tests; `linux-managed-deadline-proof.md` and options proof | Partial: Linux timeout/partial output and owned reaping are accepted in named cases; no scheduler-independent latency guarantee or full feature/platform coverage. |
| X20 | Scalar success and `linux-managed-success-proof.md` | Accepted for named Linux rows: normal completion before deadline. |
| X21 | Cap tests, `linux-process-overlap-proof.md`, managed output-limit proof | Accepted for named Linux DirectChild/Managed same-step overflow-vs-deadline cases and listed cap cases; other causes/platforms remain open. |
| X22 | `sys_process_report.rs` constructs signal reports | Open: no real Unix child-killed-by-signal observation. |
| X23 | Shared-child and `linux-process-example3-proof.md` | Accepted for named Linux rows: real spawn/wait, result map, clone snapshots and cached results. |
| X24 | Shared-child proof observes pending `wait(timeout)` and completed snapshots | Partial: a pending `try_wait` returning unit is not established by the accepted evidence. |
| X25 | Shared-child and managed-kill proofs | Accepted for named Linux cases: kill/wait completes with independent cleanup/readback. |
| X26 | Shared-child proof repeats kill after completion | Accepted for named Linux rows: repeated kill is harmless and cached snapshots persist. |
| X27 | Shared-child and managed final-drop proofs | Accepted for named Linux cases: `kill_on_drop=true` cleanup/reaping; only named feature rows. |
| X28 | `linux-drop-false-native2-proof.md`; `linux-drop-false-next.md` | Partial: exact Linux direct/managed retention tests and independent group readback are accepted at the named default Linux row, and macOS direct/managed proof is reusable; Windows and other feature rows remain open. The later `linux-drop-false-next.md` is a planning note predating native2 and does not invalidate that accepted proof. |
| X29 | Shared-child panic fixture | Open: Rust controller panic cleanup is not Rhai script `throw` cleanup. |
| X30 | No 200-run resource stability test identified | Open: no sequential-run file-descriptor/handle stability acceptance. |
| X31 | `process_representation_is_send_sync_and_shareable`; sync shared-child proof | Accepted for named Linux sync rows: shared representation and concurrent cancellation/wait behavior; actual blocking-entry and wider feature rows remain limited. |
| X32 | `tests/sys_process_windows.rs` | Open: no native Windows embedded-quote argv reconstruction test. |
| X33 | `tests/sys_process_windows.rs` | Open: no native Windows `.exe` suffix/PATH resolution test. |
| X34 | Managed deadline, output-limit, kill, final-drop and escaped-pipe proofs | Partial: selected Linux managed cancellation cases are accepted; exact platform/feature/fault breadth and Windows Job behavior remain open. |
| X35 | Managed success/held-zombie tests and `linux-managed-success-proof.md` | Partial: Linux managed leader-exit/worker closure is accepted; DirectChild distinction and other platform/feature rows need their own applicable proof. |
| X36 | `linux-post-spawn-pipe-setup-proof.md` | Open: this proves post-spawn pipe setup failure, not managed scope setup failure/no fallback. |
| X37 | Managed group/sentinel tests and accepted Linux managed proofs | Partial: named Linux host/sentinel survival is accepted; Windows Job membership and broader native rows are open. |
| X38 | `linux-managed-escaped-pipe-proof.md` | Accepted for the named Linux escaped-reader case: capture cancellation/readers close while escaped holder and sentinel survive; no other OS/feature claim. |

The crosswalk above preserves rather than reduces the original contracts. It is
an applicability map, not new execution evidence. Package B remains open, and
all partial/open rows still require their listed real observations at an
applicable revision.

### 6.8 Coverage check — no open requirement removed

| Original requirement inventory | Preserved closure route |
|---|---|
| Ticket01 public API, independent observations, meaningful RED, isolation and cleanup | Applies to A–F; no mock/compile-only closure. |
| Ticket02; P1–P9/P12/P14, E1–E5, F1–F23 | Existing foundation proof retained; native/platform/feature gaps and any invalidated path assertions close through C/D/F. Includes non-UTF8, OS-selected roots, unrestricted symlinks and macOS aliases. |
| Ticket03; P2/P10/P11/P13, X1–X38 | A/B plus native C/D and affected F rows: stdin, caching, run/raw/spawn/kill/drop, fault/setup/no-primary/first-cause, managed cancellation/completion, honest incomplete cleanup, unrelated host/sentinel and escaped pipe. No stopped criterion is declared done. |
| Compatible shared file handles and rhai-fs divergences | Existing implementation/proof retained; API docs E and native/feature/readback gaps C/D/F. Includes bounds, negative reads and unchecked behavior. |
| Tickets04/05 TCP authority/API | Accepted separate connect/listen grants, numeric IPv4/IPv6, port0 listen, bytes/text/partial progress/EOF/half-close, clone close, resource limits and sync/cancellation remain; existing Linux proof plus missing C/D/F native/feature rows. No DNS/UDP/HTTP/TLS added. |
| Ticket06; R1–R7 and release proposal | E/F preserve compatibility, metadata/docs/examples, core1.66/optional1.77.2, explicit no_std/no_object/WASM rejection, semantic feature matrix, native three-OS scope and source/dependency provenance. R4's historical alternative is resolved by rejection, not a new tuple API. |
| Process performance/diagnostics and resource safeguards | Accepted narrow Linux performance and lifecycle diagnostics remain with measurement scope; uncovered native requirements C/D/F. No duplicate benchmark solely for this revision. |
| Owner boundaries and repository outcome | No arbitrary-untrusted sandbox claim, parent env mutation, unrelated features, Actions enablement or publishing. Later verified integration only to hoppworks/rhai main, lowercase hoppworks attribution, foreign work preserved. This implementation continuation is authorized; no Git write is part of the current package step. |

All P1–P14, E1–E5, F1–F23, X1–X38, R1–R7 and the six accepted local ticket contracts
remain represented. This crosswalk is a coverage plan, not an executed acceptance
matrix or closure count. Historical implementation notes and estimates follow.

### 6.9 Historical phases — retained, superseded as execution instructions

| Phase | Deliverable | Exit criteria | Effort |
|---|---|---|---|
| 0 | This document; D1 and D2 signed off | owner reply | done |
| 1 | `sys` feature, `SysConfig`, `SysError`, env and fs functions, policy enforcement via `cap-std`, tests P1-P12, E1-E3, E5, F1-F18, R1, R2, R7 | `cargo test --features sys` green on Linux; `cargo build` without `sys` unchanged | done (30 tests in `tests/sys_policy.rs`, `tests/sys_env.rs`, `tests/sys_fs.rs`; verified under `sys`, `sys,sync`, `sys,no_index`, `sys,metadata,serde`, `sys,no_float,only_i32` and a combined minimal set) |
| 2 | `run`, `run_raw`, `spawn`, `Child`, timeout, output cap, stdin, kill-on-drop, self-reexec fixture, tests X1-X31, R3-R5 | green on Linux and macOS | one session |
| 3 | Windows pass: batch refusal, quoting, path quirks, non-UTF-8 rows, tests P13, E4, F19-F21, X32-X33; CI matrix rows | CI green on all three OS | half a session plus CI turnaround |
| 4 | Streaming file handles compatible with rhai-fs (`open_file`, `read_string`, `read_blob`, `write`, `seek`), doc-comments, `examples/sys.rs`, CHANGELOG entry, `README` section | R6; example runs | one session |
| 5 | Optional: `net` package as its own feature and plan; upstream discussion on rhaiscript/rhai issue 451 | separate document | not scheduled |

Owner time across phases 1 to 4: about three hours, mostly API review after phase 1 and
after phase 2. Names are cheap to change before phase 4 and expensive after.

## 7. Resolved questions

All five questions put to the owner on 2026-09-29 were answered with the recommendation:
in-tree behind `sys` (D1), deny-by-default (D2), `kill_on_drop` true (D9), MSRV 1.77.2 for
the gated feature only (D8), and `sys` incompatible with `no_object` via `compile_error!`
(R4, now part of D10).

## 8. Implementation notes from phase 1

- Layout: `src/packages/sys/{mod,config,error,env,fs}.rs`. Functions are closures capturing
  a `Shared<SysState>` and are registered through `FuncRegistration`, because plugin
  functions written with `#[export_module]` cannot carry per-instance configuration.
- `SysPackage::new(config)` returns `Result`, failing early when a root cannot be opened.
  `Package::init` is a no-op for the same reason.
- Absolute script paths currently match configured and canonical root prefixes.
  The review found that equivalent macOS-prefix spellings are not handled consistently;
  F23 requires repair and proof before this can be claimed as accepted behavior.
- Relative paths are checked lexically for `..` escapes before `cap-std` sees them, so the
  common case fails without touching the filesystem (P6); symlink escapes are caught by
  `cap-std` and mapped to `Denied` by inspecting its `PermissionDenied` error (P7).
- `read_file` is lossy on invalid UTF-8; `read_file_blob` is exact. `metadata().modified`
  is Unix seconds as `INT`, since Rhai's own time type is a monotonic `Instant`.
- Inside a confined root, symbolic links must have relative targets. `cap-std` treats an
  absolute link target as an escape even when it points back into the root. Documented in
  the module docs and covered by a test. The confined limitation remains accepted;
  unrestricted symlink handling has a reviewed defect and must satisfy F22.
- On Windows, `std::fs::canonicalize` returns verbatim paths (`\\?\C:\...`). Roots store
  the canonical form with that prefix stripped. The current configured-root lexical
  normalization is not the accepted contract for symlink/parent paths: P14 requires
  OS-selected root semantics. Wine evidence does not replace native Windows proof.
- Unrestricted mode currently opens the nearest existing ancestor as an ambient `Dir`.
  The review demonstrated that this imposes unintended symlink restrictions; F22
  requires ordinary host semantics. The mechanism is historical, not a design mandate.
- F19 requires a native filesystem that supports creating the non-UTF-8 fixture.
  The reviewed APFS fixture-creation failure is a coverage limitation; repair the
  fixture handling and obtain appropriate native evidence without weakening NotUtf8.

## Appendix A: precedents, condensed

What each reference contributed to sections 3 and 4. Nothing was copied; each row was
written against the contract above.

| Reference | Taken | Not taken |
|---|---|---|
| Rust `std::process::Command`, `std::fs` | API vocabulary (`env_clear`, `env_remove`, `current_dir`, `kill_on_drop`), non-zero exit as data, concurrent pipe draining in `output()`, `try_wait`, `ExitStatusExt::signal`, the self-reexec fixture pattern | nothing; this is the substrate |
| Deno `Deno.Command` and permissions | Options-object style, `--allow-run` and `--allow-read` as the authority model, `clearEnv`, signal degradation on Windows | async surface, `Deno.ChildProcess` streams |
| `cap-std` | Root-confined `Dir` handles; symlink-safe path resolution | its own I/O traits; scripts see strings only |
| rune-modules `process` | Confirmation that the builder style is awkward in a scripting binding; `kill_on_drop`; `Output` field names | builder API, tokio dependency |
| rhai-fs | Function names for overlapping fs operations, `Shared<Locked<File>>` handle pattern, `sync` handling | `PathBuf` opaque type in v0.1 |
| Lua 5.4 `io`/`os` and `testes/files.lua` | Failure-path cases: missing file, empty file, binary data, remove and rename errors, cleanup after many operations | `os.execute` and `io.popen` shell semantics |
| QuickJS `std`/`os` | Feature checklist: cwd, env, stdin/stdout/stderr control, `waitpid`, `stat`, `mkdir`, signals | fd-level API, POSIX-only errors |
| mruby `mruby-io`, `mruby-socket` | Confirmation that fs and net belong in separate optional packages | packaging and test layout (dictated by Cargo and Rhai here) |
| CVE-2024-24576 (Rust advisory) | D8 and P13 | |

## Appendix B: sources

- Rust `std::process`: https://doc.rust-lang.org/std/process/struct.Command.html
- Rust advisory for batch-file argument injection: https://blog.rust-lang.org/2024/04/09/cve-2024-24576.html
- Deno `Deno.Command`: https://docs.deno.com/api/deno/~/Deno.Command
- Deno permissions: https://docs.deno.com/runtime/fundamentals/security/
- cap-std: https://github.com/bytecodealliance/cap-std
- rune-modules process: https://github.com/rune-rs/rune/blob/main/crates/rune-modules/src/process.rs
- rhai-fs: https://github.com/rhaiscript/rhai-fs
- rhai-net (stalled, TCP only): https://github.com/emesare/rhai-net
- Lua 5.4 manual, I/O and OS libraries: https://www.lua.org/manual/5.4/manual.html#6.8
- Lua file tests: https://github.com/lua/lua/blob/master/testes/files.lua
- QuickJS `std` and `os` modules: https://bellard.org/quickjs/quickjs.html
- mruby gems: https://github.com/mruby/mruby/tree/master/mrbgems
- Original issue: https://github.com/rhaiscript/rhai/issues/451
